#include<iostream>
#include "pch.h"
#include "../Lab01/Header.h"
using namespace std;
// Question 1
TEST(EmployeeSortTest, SortBySalary) {
    // Example employee records
    EmployeeRecord employees[] = {
        {101, "Alice", 50000},
        {102, "Bob", 75000},
        {103, "Charlie", 60000},
        {104, "Diana", 40000},
        {105, "Eve", 70000}
    };

    int size = sizeof(employees) / sizeof(employees[0]);

    // Expected sorted employee records (by salary)
    EmployeeRecord expected[] = {
        {104, "Diana", 40000},
        {101, "Alice", 50000},
        {103, "Charlie", 60000},
        {105, "Eve", 70000},
        {102, "Bob", 75000}
    };

    // Sort the employee records by salary
    bubbleSortEmployees(employees, size);

    // Check if the sorted employees match the expected result
    for (int i = 0; i < size; i++) {
        EXPECT_EQ(employees[i].employeeID, expected[i].employeeID);
        EXPECT_EQ(employees[i].name, expected[i].name);  
        EXPECT_EQ(employees[i].salary, expected[i].salary);  
    }
}
// Question 2
TEST(SelectionSortTest, UpperLowerCase) {
    char test1[] = "zDvLagT";
    int n1 = sizeof(test1) / sizeof(test1[0]) - 1; // Adjust size to exclude null terminator
    sortUpperLowerSeparately(test1, n1);
    char t[] = "agvzDLT";
    for (int i = 0; i < n1; i++) {
        EXPECT_EQ(test1[i], t[i]);
    }
}
// Question 3
TEST(LinearSearchTest, BasicTests) {
    // Test case 1: Target is found in the array
    const int numStrings1 = 5;
    string strings1[numStrings1] = { "apple", "banana", "cherry", "date", "elderberry" };
    int result1 = linearSearchString(strings1, numStrings1, "cherry");
    EXPECT_EQ(result1, 2);  // Expected index is 2

    // Test case 2: Target is not found in the array
    int result2 = linearSearchString(strings1, numStrings1, "fig");
    EXPECT_EQ(result2, -1); // Expected result is -1 since "fig" is not in the array
}
// Question 4
TEST(BinarySearch2DTest, ThreeByThreeArray) {
    // Test case 1: 4x4 array
    int arr1[4][4] = {
        {10,20,30,40},
        {50,60,70,80},
        {90,95,100,105 }, 
        { 104,115,125,130 }
    };

    // Target is found
    int target1 = 30;
    bool result1 = binarySearch2D(arr1, 4, 4, target1);
    EXPECT_TRUE(result1);  // Expected to be found

    // Target is not found
    int target2 = 2;
    bool result2 = binarySearch2D(arr1, 4, 4, target2);
    EXPECT_FALSE(result2);  // Expected not to be found
}
