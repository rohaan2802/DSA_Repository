#include<iostream>
#include "pch.h"
#include "../Lab01/Header.h"
using namespace std;
//--------------1st Question--------------

TEST(BinaryTreeTest, InsertAndDisplay) {
    BinaryTree tree;
    tree.insert(1);
    tree.insert(2);
    tree.insert(3);
    tree.insert(4);
    tree.insert(5);
    tree.insert(6);

    // Displaying the tree structure
    std::cout << "Complete Binary Tree Structure:" << std::endl;
    std::cout << "     " << "1" << std::endl;
    std::cout << "    / \\" << std::endl;
    std::cout << "   " << "2" << "   " << "3" << std::endl;
    std::cout << "  / \\ / " << std::endl;
    std::cout << "  " << "4" << " " << "5" << " " << "6" << std::endl;

    testing::internal::CaptureStdout();
    tree.Display();
    std::string output = testing::internal::GetCapturedStdout();

    ASSERT_EQ(output, "Inorder Traversal: 4 2 5 1 6 3 Preorder Traversal: 1 2 4 5 3 6 Postorder Traversal: 4 5 2 6 3 1 ");
}
//--------------2nd Question--------------
TEST(FindPathSum, case1) {
    // Constructing the binary tree based on the image provided
    Node* root = new Node(10);
    root->left = new Node(8);
    root->right = new Node(2);
    root->left->left = new Node(3);
    root->left->right = new Node(5);
    root->right->right = new Node(2);

    // Example target sum
    int targetSum = 14;

    // Checking if the path with the given target sum exists
    EXPECT_TRUE(hasPathSum(root, targetSum));
}