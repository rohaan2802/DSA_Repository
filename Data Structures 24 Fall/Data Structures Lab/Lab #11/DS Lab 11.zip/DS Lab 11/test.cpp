#include<iostream>
#include "pch.h"
#include "../Lab01/Header.h"
using namespace std;
//--------------1st Question--------------
TEST(BSTTest, InsertAndSearch) {
    BST bst;
    bst.insert(50);
    bst.insert(30);
    bst.insert(20);
    bst.insert(40);
    bst.insert(70);
    bst.insert(60);
    bst.insert(80);

    testing::internal::CaptureStdout();
    bst.inorderTraversal();
    string inOrderOutput = testing::internal::GetCapturedStdout();
    string expectedinOrder = "20 30 40 50 60 70 80 \n";
    EXPECT_EQ(inOrderOutput, expectedinOrder);

    testing::internal::CaptureStdout();
    bst.preorderTraversal();
    string preOrderOutput = testing::internal::GetCapturedStdout();
    string expectedPreOrder = "50 30 20 40 70 60 80 \n";
    EXPECT_EQ(preOrderOutput, expectedPreOrder);

    testing::internal::CaptureStdout();
    bst.postorderTraversal();
    string postOrderOutput = testing::internal::GetCapturedStdout();
    string expectedPostOrder = "20 40 30 60 80 70 50 \n";
    EXPECT_EQ(postOrderOutput, expectedPostOrder);

    EXPECT_TRUE(bst.search(50));
    EXPECT_TRUE(bst.search(30));
    EXPECT_TRUE(bst.search(20));
    EXPECT_TRUE(bst.search(40));
    EXPECT_TRUE(bst.search(70));
    EXPECT_TRUE(bst.search(60));
    EXPECT_FALSE(bst.search(90));
}
TEST(BSTDeletion, OneOrNoChild) {
    BST bst;

    bst.insert(50);
    bst.insert(30);
    bst.insert(20);
    bst.insert(40);
    bst.insert(70);
    bst.insert(60);
    bst.insert(45);
    bst.insert(35);
    bst.insert(19);

    bst.remove(19); //having no child means leaf node deletion
    bst.remove(70);  //having one child

    EXPECT_TRUE(bst.search(20));
    EXPECT_TRUE(bst.search(30));
    EXPECT_FALSE(bst.search(19));
    EXPECT_FALSE(bst.search(70));
    EXPECT_TRUE(bst.search(50));
    EXPECT_TRUE(bst.search(20));
    EXPECT_TRUE(bst.search(40));
    EXPECT_TRUE(bst.search(60));
    EXPECT_FALSE(bst.search(80));
}
TEST(BSTDeletion, TwoChild) {
    BST bst;

    bst.insert(50);
    bst.insert(30);
    bst.insert(20);
    bst.insert(40);
    bst.insert(70);
    bst.insert(60);
    bst.insert(80);

    bst.remove(30);  //having two child
    bst.remove(70);  //having two child

    testing::internal::CaptureStdout();
    bst.postorderTraversal();
    string postOrderOutput = testing::internal::GetCapturedStdout();
    string expectedPostOrder = "20 40 60 80 50 \n";
    EXPECT_EQ(postOrderOutput, expectedPostOrder);
}
TEST(LeafNodeCount, case1) {
    BST bst;

    bst.insert(5);
    bst.insert(10);
    bst.insert(15);
    bst.insert(20);
    bst.insert(25);
    bst.insert(30);
    bst.insert(35);
    bst.insert(40);
    bst.insert(45);

    int leaf_count = bst.countLeafNodes();
    EXPECT_EQ(leaf_count, 1);
}
TEST(LeafNodeCount, case2) {
    BST bst;

    bst.insert(50);
    bst.insert(30);
    bst.insert(70);
    bst.insert(20);
    bst.insert(35);
    bst.insert(60);
    bst.insert(78);
    bst.insert(2);
    bst.insert(21);

    int leaf_count = bst.countLeafNodes();
    EXPECT_EQ(leaf_count, 5);

    bst.remove(2);
    bst.remove(21);

    leaf_count = bst.countLeafNodes();
    EXPECT_EQ(leaf_count, 4);
}