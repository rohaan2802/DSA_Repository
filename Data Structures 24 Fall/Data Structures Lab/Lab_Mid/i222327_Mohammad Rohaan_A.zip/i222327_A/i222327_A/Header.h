#pragma once
#include<iostream>
using namespace std;


class Node
{
public:

	Node* next;
	Node* previous;
	int data;
	Node(int x=0)
	{
		next = previous = nullptr;
		data = x;
	}
};

class CDLL
{
	Node* head;
public:
	CDLL()
	{
		head = nullptr;
	}
	void inser_at_begining(int data)
	{
		Node* new_node = new Node(data);
		if (head == nullptr)
		{
			head = new_node;
			return;
		}
		new_node->next = head;
		head->previous = new_node;
		head = new_node;
		
	}

	void insert_at_end(int data)
	{
		Node* new_node = new Node(data);
		if (head == nullptr)
		{
			head = new_node;
			return;
		}
		Node* current = head;
		while (current->next != head)
		{
			current = current->next;
		}
		current->next = new_node;
		new_node->previous = current;
		new_node->next = head;
		head->previous = new_node;

	}

	void insert_at_position(int data, int pos)
	{

		Node* new_node = new Node(data);
		if (head == nullptr)
		{
			head = new_node;
			return;
		}
		Node* current = head;
		int count = 1;
		while (current->next != head && count < pos)
		{
			current = current->next;
			count++;
		}
		new_node->next = current->next;
		current->next->previous = new_node;
		new_node->previous = current;
		current->next = new_node;
	}
		
	void delete_at_begining()
	{
		if (head == nullptr)
		{
			return;
		}
		Node* temp = head;
		
		head = head->next;

		delete temp;
	}

	void delete_at_end()
	{
		if (head == nullptr)
		{
			return;
		}
		Node* current = head;
		while (current->next->next != head)
		{
			current = current->next;
		}
		Node* temp = current->next;
		current->next = head;
		head->previous = current;
		delete temp;
	}

	void delete_at_position(int pos)
	{
		if (head == nullptr)
		{
			
			return;
		}
		Node* current = head;
		int count = 1;
		while (current->next != head && count < pos)
		{
			current = current->next;
			count++;
		}
		Node* temp = current->next;
		current->next = current->next->next;
		current->next->next->previous = current;
		delete temp;

	}

	void print()
	{
		Node* current = head;
		while (current->next!=head)
		{
			cout << current->data;
			current = current->next;
		}
	}

	void repaint_at_Position(int val,int pos)
	{
		if (head == nullptr)
		{

			return;
		}
		Node* current = head;
		int count = 1;
		while (current->next != head && count < pos)
		{
			current = current->next;
			count++;
		}
		current->next->data = val;
	}
	
	void repaint_at_Match(int x,int val) // if the x matches the data
	{
		if (head == nullptr)
		{

			return;
		}
		Node* current = head;
		int count = 1;
		while (current->next->data != x )
		{
			current = current->next;
			count++;
		}
		current->next->data = val;
	}
};