#include<iostream>
#include"Header.h"
using namespace std;

int main()
{
	
	while (true)
	{
		cout << "1) ADD BULB AT START\n";
		cout << "2) ADD BULB AT END\n";
		cout << "3) ADD BULB AT SPECIFIED POSITION\n";
		cout << "4) DELETE BULB AT START\n";
		cout << "5) DELETE BULB AT END\n";
		cout << "6) DELETE BULB AT SPECIFIED POSITION\n";
		cout << "7) CHANGE THE COLOR OF BULB\n";
		cout << "8) DISPLAY BEAUTY\n";
		cout << "9) EXIT\n";
		int input;
		cout << "\n\nSELECT THE OPTION FROM ABOVE MENU          "; 
		cin >> input;
		switch (input)
		{
		case 1:
			break;
		default:
			break;
		}
	}


}


// Not Enough time to Complete the Main Function but Have Implement all the functionality